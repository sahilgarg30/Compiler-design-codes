Compiler Project : ERPLAG
This project was created by a group of 3 Students- Sahil Garg, Jenit Jain and Amrit Goyal as a part of the course lab ”Compiler Design”. The language is "ERPLAG" and its specifications are written down in the PDF attached.

Instructor : Roopashri Shetty

How to run
In the Final project directory, just type the following commands

	make
	compiler name_of_file

where "name_of_file" is the input test file (like "testcase1.txt”).
You should have gcc, version 5.0 or above installed on your machine.
